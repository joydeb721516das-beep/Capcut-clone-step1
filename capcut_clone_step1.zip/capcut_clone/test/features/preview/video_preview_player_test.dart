import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:capcut_clone/features/preview/video_preview_controller.dart';
import 'package:capcut_clone/features/preview/video_preview_player.dart';
import 'fake_video_player_service.dart';

void main() {
  testWidgets('shows placeholder for a non-platform service and toggles icon',
      (tester) async {
    final controller = VideoPreviewController(FakeVideoPlayerService());
    await controller.loadAndPlay('/fake/path.mp4');

    await tester.pumpWidget(
      MaterialApp(home: VideoPreviewPlayer(controller: controller)),
    );
    await tester.pump();

    // FakeVideoPlayerService isn't the real platform service, so
    // platformController is null and the placeholder should render.
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // loadAndPlay already started playback.
    expect(find.byIcon(Icons.pause_circle), findsOneWidget);

    await tester.tap(find.byKey(const Key('playPauseButton')));
    await tester.pump();

    expect(find.byIcon(Icons.play_circle), findsOneWidget);
  });
}
