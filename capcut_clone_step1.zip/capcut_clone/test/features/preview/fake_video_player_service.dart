import 'dart:async';
import 'package:capcut_clone/core/video_player_service.dart';

/// In-memory fake used by unit tests. No platform channel, no real file.
class FakeVideoPlayerService implements VideoPlayerService {
  final _controller = StreamController<void>.broadcast();

  String? loadedPath;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _duration = const Duration(seconds: 10); // arbitrary fixed length

  @override
  Stream<void> get onChanged => _controller.stream;

  @override
  Future<void> load(String filePath) async {
    loadedPath = filePath;
    _position = Duration.zero;
    _controller.add(null);
  }

  @override
  Future<void> play() async {
    _isPlaying = true;
    _controller.add(null);
  }

  @override
  Future<void> pause() async {
    _isPlaying = false;
    _controller.add(null);
  }

  @override
  Future<void> seekTo(Duration position) async {
    _position = position;
    _controller.add(null);
  }

  @override
  Future<void> dispose() async {
    await _controller.close();
  }

  @override
  bool get isPlaying => _isPlaying;

  @override
  Duration get position => _position;

  @override
  Duration get duration => _duration;
}
