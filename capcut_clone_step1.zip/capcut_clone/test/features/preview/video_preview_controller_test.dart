import 'package:flutter_test/flutter_test.dart';
import 'package:capcut_clone/features/preview/video_preview_controller.dart';
import 'fake_video_player_service.dart';

void main() {
  group('VideoPreviewController', () {
    late FakeVideoPlayerService fakeService;
    late VideoPreviewController controller;

    setUp(() {
      fakeService = FakeVideoPlayerService();
      controller = VideoPreviewController(fakeService);
    });

    test('starts not playing with zero position', () {
      expect(controller.isPlaying, isFalse);
      expect(controller.position, Duration.zero);
    });

    test('loadAndPlay loads the file into the service and starts playback',
        () async {
      await controller.loadAndPlay('/fake/path/clip.mp4');

      expect(fakeService.loadedPath, '/fake/path/clip.mp4');
      expect(controller.isPlaying, isTrue);
    });

    test('togglePlayPause pauses when playing', () async {
      await controller.loadAndPlay('/fake/path/clip.mp4');
      expect(controller.isPlaying, isTrue);

      await controller.togglePlayPause();

      expect(controller.isPlaying, isFalse);
    });

    test('togglePlayPause resumes when paused', () async {
      await controller.loadAndPlay('/fake/path/clip.mp4');
      await controller.togglePlayPause(); // now paused
      await controller.togglePlayPause(); // should resume

      expect(controller.isPlaying, isTrue);
    });

    test('seek updates position', () async {
      await controller.loadAndPlay('/fake/path/clip.mp4');

      await controller.seek(const Duration(seconds: 3));

      expect(controller.position, const Duration(seconds: 3));
    });

    test('notifies listeners when underlying service state changes',
        () async {
      var notifyCount = 0;
      controller.addListener(() => notifyCount++);

      await controller.loadAndPlay('/fake/path/clip.mp4');

      expect(notifyCount, greaterThan(0));
    });
  });
}
