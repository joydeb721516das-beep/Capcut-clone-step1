# capcut_clone — Step 1 (Project setup + video preview player)

## What's actually in this zip

- `lib/core/video_player_service.dart` — abstract playback interface (for testability)
- `lib/core/video_player_package_service.dart` — real implementation (wraps `package:video_player`)
- `lib/features/preview/video_preview_controller.dart` — UI state holder
- `lib/features/preview/video_preview_player.dart` — the preview widget + play/pause button
- `lib/main.dart` — app entry point, file picker → preview
- `test/` — unit test for the controller (logic only, no real video) + widget test
- `.github/workflows/flutter-ci.yml` — runs tests and builds the APK in the cloud

**No `android/` folder is included.** It's machine-generated boilerplate
tied to your exact Flutter/Gradle/AGP versions — hand-writing it here
risked shipping something subtly broken that I have no way to catch.
The CI workflow generates it automatically with `flutter create`.

## How to build this with no local terminal (phone only)

1. Create a new GitHub repo (GitHub mobile app, or github.com in your
   phone browser).
2. Upload every file in this zip, preserving the folder structure
   (github.com's web upload supports drag-and-drop of a whole folder
   from most mobile browsers; the GitHub app doesn't support bulk
   folder upload, so the browser is easier for this).
3. Push/commit to `main`. This triggers `.github/workflows/flutter-ci.yml`
   automatically.
4. Open the **Actions** tab on the repo → the running workflow. It
   will: generate the Android scaffold → `flutter pub get` →
   **`flutter test`** (this is your real RED/GREEN result — check it
   actually says all tests passed, not just that the job finished) →
   `flutter build apk --release`.
5. Once green, open the finished workflow run → **Artifacts** →
   download `app-release-apk`. That's your installable APK.

## Known follow-ups (not blocking Step 1)

- On Android 13+ (API 33+), picking video via `file_picker` may need
  `READ_MEDIA_VIDEO` declared in `android/app/src/main/AndroidManifest.xml`
  depending on which picker mode gets used at runtime. If video
  selection silently fails on a real device, this is the first thing
  to check — add it and rebuild.
- This whole `video_player`-based renderer is scaffolding. Step 2
  replaces it with the custom OpenGL/`SurfaceTexture` pipeline
  described in the architecture doc, behind the same
  `VideoPlayerService` interface, so `main.dart` and the widget won't
  need to change.
