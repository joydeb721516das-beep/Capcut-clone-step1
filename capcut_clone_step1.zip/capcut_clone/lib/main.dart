import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'core/video_player_package_service.dart';
import 'features/preview/video_preview_controller.dart';
import 'features/preview/video_preview_player.dart';

void main() {
  runApp(const CapCutCloneApp());
}

class CapCutCloneApp extends StatelessWidget {
  const CapCutCloneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Offline Video Editor',
      theme: ThemeData.dark(useMaterial3: true),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final VideoPreviewController _previewController;
  bool _hasClip = false;

  @override
  void initState() {
    super.initState();
    _previewController = VideoPreviewController(VideoPlayerPackageService());
  }

  Future<void> _pickAndLoadVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video);
    final path = result?.files.single.path;
    if (path == null) return;

    await _previewController.loadAndPlay(path);
    setState(() => _hasClip = true);
  }

  @override
  void dispose() {
    _previewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Offline Video Editor')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_hasClip)
                VideoPreviewPlayer(controller: _previewController)
              else
                const Text('No video selected yet.'),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _pickAndLoadVideo,
                icon: const Icon(Icons.video_library),
                label: const Text('Pick a video'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
