import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'video_preview_controller.dart';

/// Renders the current clip with a play/pause control.
///
/// Reads `controller.platformController` to get actual video frames.
/// When that's null (loading, or a fake service in tests), shows a
/// placeholder instead of crashing.
class VideoPreviewPlayer extends StatefulWidget {
  const VideoPreviewPlayer({super.key, required this.controller});

  final VideoPreviewController controller;

  @override
  State<VideoPreviewPlayer> createState() => _VideoPreviewPlayerState();
}

class _VideoPreviewPlayerState extends State<VideoPreviewPlayer> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onControllerChanged);
  }

  void _onControllerChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final VideoPlayerController? platformController =
        widget.controller.platformController;
    final bool ready = platformController != null &&
        platformController.value.isInitialized;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AspectRatio(
          aspectRatio: ready ? platformController.value.aspectRatio : 16 / 9,
          child: ready
              ? VideoPlayer(platformController)
              : const ColoredBox(
                  color: Colors.black12,
                  child: Center(child: CircularProgressIndicator()),
                ),
        ),
        const SizedBox(height: 8),
        IconButton(
          key: const Key('playPauseButton'),
          iconSize: 48,
          icon: Icon(
            widget.controller.isPlaying
                ? Icons.pause_circle
                : Icons.play_circle,
          ),
          onPressed: widget.controller.togglePlayPause,
        ),
      ],
    );
  }
}
