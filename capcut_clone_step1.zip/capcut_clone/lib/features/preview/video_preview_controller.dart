import 'package:flutter/foundation.dart';
import 'package:video_player/video_player.dart';
import 'package:capcut_clone/core/video_player_service.dart';
import 'package:capcut_clone/core/video_player_package_service.dart';

/// UI-facing state holder for the preview player. Depends on the
/// abstract VideoPlayerService, not on package:video_player directly,
/// so this class is unit-testable with FakeVideoPlayerService and
/// unaffected when the renderer changes later.
class VideoPreviewController extends ChangeNotifier {
  VideoPreviewController(this._service) {
    _service.onChanged.listen((_) => notifyListeners());
  }

  final VideoPlayerService _service;

  bool get isPlaying => _service.isPlaying;
  Duration get position => _service.position;
  Duration get duration => _service.duration;

  /// Only non-null when the concrete service is the real package-backed
  /// one — needed so the widget can render actual video frames. Kept
  /// out of the abstract interface deliberately (see
  /// VideoPlayerPackageService's doc comment).
  VideoPlayerController? get platformController {
    final service = _service;
    if (service is VideoPlayerPackageService) {
      return service.controller;
    }
    return null;
  }

  Future<void> loadAndPlay(String filePath) async {
    await _service.load(filePath);
    await _service.play();
  }

  Future<void> togglePlayPause() async {
    if (_service.isPlaying) {
      await _service.pause();
    } else {
      await _service.play();
    }
  }

  Future<void> seek(Duration position) async {
    await _service.seekTo(position);
  }

  @override
  void dispose() {
    _service.dispose();
    super.dispose();
  }
}
