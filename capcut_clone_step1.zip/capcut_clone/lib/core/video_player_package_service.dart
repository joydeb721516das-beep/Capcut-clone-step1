import 'dart:async';
import 'dart:io';
import 'package:video_player/video_player.dart';
import 'video_player_service.dart';

/// Real implementation backed by package:video_player.
///
/// This is Step 1 scaffolding. It gets swapped out (behind the same
/// VideoPlayerService interface, so nothing else changes) once the
/// custom OpenGL renderer exists for filters/transitions.
class VideoPlayerPackageService implements VideoPlayerService {
  VideoPlayerController? _controller;
  final _changeController = StreamController<void>.broadcast();

  /// Exposed for the widget layer to render frames via the `VideoPlayer`
  /// widget. Not part of the abstract interface on purpose — this is a
  /// deliberate, temporary leak while video_player is our renderer.
  VideoPlayerController? get controller => _controller;

  @override
  Stream<void> get onChanged => _changeController.stream;

  @override
  Future<void> load(String filePath) async {
    await _controller?.dispose();

    final newController = VideoPlayerController.file(File(filePath));
    _controller = newController;
    newController.addListener(_onTick);

    await newController.initialize();
    _changeController.add(null);
  }

  void _onTick() => _changeController.add(null);

  @override
  Future<void> play() async {
    await _controller?.play();
  }

  @override
  Future<void> pause() async {
    await _controller?.pause();
  }

  @override
  Future<void> seekTo(Duration position) async {
    await _controller?.seekTo(position);
  }

  @override
  Future<void> dispose() async {
    _controller?.removeListener(_onTick);
    await _controller?.dispose();
    await _changeController.close();
  }

  @override
  bool get isPlaying => _controller?.value.isPlaying ?? false;

  @override
  Duration get position => _controller?.value.position ?? Duration.zero;

  @override
  Duration get duration => _controller?.value.duration ?? Duration.zero;
}
