/// Abstraction over "something that can play a local video file."
///
/// Deliberately NOT tied to package:video_player's concrete controller.
/// This is what lets VideoPreviewController be unit-tested with a fake,
/// and lets Step 2+ swap in the custom OpenGL renderer without touching
/// controller or widget code.
abstract class VideoPlayerService {
  Future<void> load(String filePath);
  Future<void> play();
  Future<void> pause();
  Future<void> seekTo(Duration position);
  Future<void> dispose();

  bool get isPlaying;
  Duration get position;
  Duration get duration;

  /// Fires whenever playback state changes (play/pause/seek/position tick).
  Stream<void> get onChanged;
}
